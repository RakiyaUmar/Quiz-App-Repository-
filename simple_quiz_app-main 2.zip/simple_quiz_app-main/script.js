const questions = [
    {
        question: "What Is The Most Popular Programming Language Used For Web Development?",
        answers: [
            {  text: "Python", correct: false},
            {  text: "JavaScript", correct: true},
            {  text: "HTML/CSS", correct: false},
            {  text: "Java", correct: false},
        ]
    },
    {
        question: "Which database management system is known for its ability to handle large amounts of data and scale horizontally?",
        answers: [
            {  text: "MySQL", correct: false},
            {  text: "MongoDB", correct: true},
            {  text: "PostgreSQL", correct: false},
            {  text: "Microsoft SQL server", correct: false},
        ]
    },
    {
        question: "Is ALX best for a nigerian to learn software engineering?",
        answers: [
            {  text: "No", correct: false},
            {  text: "Maybe", correct: false},
            {  text: "Yes, Sure", correct: true},
            {  text: "Not sure", correct: false},
        ]
    },
    {
        question: "What is the first process of ensuring that a software system meet its requirements and works as expected?",
        answers: [
            {  text: "Debugging", correct: false},
            {  text: "Maintenance", correct: false},
            {  text: "Deployment", correct: false},
            {  text: "Testing", correct: true},
        ]
    },
]

const questionElement = document.getElementById("question");
const answerButtons = document.getElementById("answer-buttons");
const nextButton = document.getElementById("next-btn");

let currentQuestionIndex = 0;
let score = 0;

function startQuiz() {
    currentQuestionIndex = 0;
    score = 0;
    nextButton.innerHTML = "Next";
    showQuestion();
}

function showQuestion() {
    resetState();
    let currentQuestion = questions[currentQuestionIndex];
    let questionnum = currentQuestionIndex + 1;
    questionElement.innerHTML = questionnum + ". " + currentQuestion.question;

    currentQuestion.answers.forEach(answer => {
        const button = document.createElement("button");
        button.innerHTML =  answer.text;
        button.classList.add("btn");
        answerButtons.appendChild(button);
        if(answer.correct){
            button.dataset.correct = answer.correct
        }
        button.addEventListener("click", selectAnswer);
    });
}

function resetState() {
    nextButton.style.display = "none";
    while(answerButtons.firstChild){
        answerButtons.removeChild(answerButtons.firstChild);
    }
}

function selectAnswer(e){
    const selectedBtn = e.target;
    const isCorrect = selectedBtn.dataset.correct === "true";
    if(isCorrect) {
        selectedBtn.classList.add("correct");
        score++;
    } else{
        selectedBtn.classList.add("incorrect");
    }
    Array.from(answerButtons.children).forEach(button => {
         if(button.dataset.correct === "true"){
            button.classList.add("correct");
         }
         button.disabled = true;
    });
    nextButton.style.display = "block";
}

function showScore(){
    resetState();
    questionElement.innerHTML = `You scored ${score} out of ${questions.length}!`;
    nextButton.innerHTML = "Restart Quiz";
    nextButton.style.display = "block";
}

function handleNextButton(){
    currentQuestionIndex++;
    if(currentQuestionIndex < questions.length){
        showQuestion();
    } else {
        showScore();
    }
}


nextButton.addEventListener("click", ()=>{
    if(currentQuestionIndex < questions.length){
        handleNextButton();
    } else {
        startQuiz();
    }
});

startQuiz();