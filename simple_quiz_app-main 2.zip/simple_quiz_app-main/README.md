# Simple quiz app
A simple quiz application made with html, css and javascript

## link to the quiz app: 
